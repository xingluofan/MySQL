<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `admin_log`;");
E_C("CREATE TABLE `admin_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `ip` varchar(30) NOT NULL,
  `timer` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=gbk");
E_D("replace into `admin_log` values('2','admin','192.168.1.101','2010-06-16 11:16:30');");
E_D("replace into `admin_log` values('3','admin','127.0.0.1','2010-06-18 13:51:57');");

require("../../inc/footer.php");
?>