<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `admin_newstype`;");
E_C("CREATE TABLE `admin_newstype` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `descr` varchar(255) DEFAULT NULL,
  `timer` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=gbk");
E_D("replace into `admin_newstype` values('10','��ѯ��ע',NULL,NULL);");
E_D("replace into `admin_newstype` values('11','��������','��������','2010-06-11 15:10:41');");
E_D("replace into `admin_newstype` values('12','У������','1','2010-06-12 10:13:54');");

require("../../inc/footer.php");
?>