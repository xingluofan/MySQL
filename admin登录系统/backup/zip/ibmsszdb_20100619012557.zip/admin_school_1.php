<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `admin_school`;");
E_C("CREATE TABLE `admin_school` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL,
  `con` text NOT NULL,
  `img` varchar(255) DEFAULT NULL,
  `imgsend` varchar(1) DEFAULT '',
  `timer` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=gbk");
E_D("replace into `admin_school` values('15','ѧУ����','ѧУ���','<p>����</p>','../upload/image1276079872.jpg','0','2010-06-12 10:14:49');");

require("../../inc/footer.php");
?>