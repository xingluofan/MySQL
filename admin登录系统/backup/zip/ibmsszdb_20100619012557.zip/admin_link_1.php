<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `admin_link`;");
E_C("CREATE TABLE `admin_link` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `webname` varchar(255) NOT NULL,
  `webdizhi` varchar(255) NOT NULL,
  `webdescr` varchar(255) DEFAULT NULL,
  `weblogo` varchar(255) DEFAULT NULL,
  `timer` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=gbk");
E_D("replace into `admin_link` values('13','�ٶ�','�ٶ�','�ٶ�','../upload/image/16.gif','2010-06-16 10:08:16');");
E_D("replace into `admin_link` values('14','�Ѻ�','�Ѻ�','�Ѻ�','../upload/image/2006110214174451464.jpg','2010-06-16 10:17:05');");
E_D("replace into `admin_link` values('15','���԰�','','','','2010-06-16 10:18:11');");

require("../../inc/footer.php");
?>