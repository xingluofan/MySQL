<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `admin`;");
E_C("CREATE TABLE `admin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(50) NOT NULL,
  `admin_pwd` varchar(50) NOT NULL,
  `timer` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=gbk");
E_D("replace into `admin` values('1','admin','admin','2010-05-30 08:03:17');");
E_D("replace into `admin` values('3','jzq','jzq','2010-06-06 19:25:44');");

require("../../inc/footer.php");
?>