<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `admin_schooltype`;");
E_C("CREATE TABLE `admin_schooltype` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `descr` varchar(255) DEFAULT NULL,
  `timer` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=gbk");
E_D("replace into `admin_schooltype` values('17','ѧУ���','ѧУ���','2010-06-09 11:58:51');");
E_D("replace into `admin_schooltype` values('18','ѧУ����','ѧУ����','2010-06-12 10:12:42');");

require("../../inc/footer.php");
?>