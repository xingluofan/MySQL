<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `admin_questiontype`;");
E_C("CREATE TABLE `admin_questiontype` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `descr` varchar(255) DEFAULT NULL,
  `timer` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=gbk");
E_D("replace into `admin_questiontype` values('1','������',NULL,'2010-06-07 11:03:06');");
E_D("replace into `admin_questiontype` values('3','��ѧ��','��ѧ��1','2010-06-11 15:12:04');");

require("../../inc/footer.php");
?>