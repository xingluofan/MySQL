<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `admin_cul`;");
E_C("CREATE TABLE `admin_cul` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `type` varchar(50) NOT NULL,
  `laiyuan` varchar(100) DEFAULT NULL,
  `author` varchar(50) NOT NULL,
  `con` text NOT NULL,
  `img` varchar(255) DEFAULT NULL,
  `timer` datetime NOT NULL,
  `imgsend` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk");

require("../../inc/footer.php");
?>