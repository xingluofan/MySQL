<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `admin_info`;");
E_C("CREATE TABLE `admin_info` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `webname` varchar(255) NOT NULL,
  `webdizhi` varchar(255) DEFAULT NULL,
  `webyoubian` varchar(255) DEFAULT NULL,
  `webtit` varchar(255) DEFAULT NULL,
  `webchuanzhen` varchar(255) DEFAULT NULL,
  `webemail` varchar(255) DEFAULT NULL,
  `webkey` varchar(255) DEFAULT NULL,
  `webdescr` varchar(255) DEFAULT NULL,
  `webicp` varchar(255) DEFAULT NULL,
  `weblogo` varchar(255) DEFAULT NULL,
  `webqq` varchar(255) DEFAULT NULL,
  `webqq2` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=gbk");
E_D("replace into `admin_info` values('1','IBM˳ʱ���������ѧУ','www.ibmssz.com','150030','133232442','242424','23232323','12','���ۺ���һ���ѧУ','05006930','../upload/image/05.jpg','2323232','232323');");

require("../../inc/footer.php");
?>