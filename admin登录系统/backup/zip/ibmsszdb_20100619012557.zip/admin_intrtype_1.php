<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `admin_intrtype`;");
E_C("CREATE TABLE `admin_intrtype` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `descr` varchar(255) DEFAULT NULL,
  `timer` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=gbk");
E_D("replace into `admin_intrtype` values('6','��������','����',NULL);");
E_D("replace into `admin_intrtype` values('8','���繤��','���繤1��','2010-06-11 11:24:59');");
E_D("replace into `admin_intrtype` values('9','�������','qqq','2010-06-12 10:13:23');");

require("../../inc/footer.php");
?>