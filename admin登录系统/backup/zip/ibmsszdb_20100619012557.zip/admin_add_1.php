<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `admin_add`;");
E_C("CREATE TABLE `admin_add` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `dizhi` varchar(255) NOT NULL,
  `tit` varchar(100) NOT NULL,
  `chuanzhen` varchar(255) DEFAULT NULL,
  `qq` varchar(255) DEFAULT NULL,
  `qq2` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=gbk");
E_D("replace into `admin_add` values('1','ibm˳ʱ����������ѧУ','���������㷻��ũ�ƽ�19��','123456789','987654321','123456','654321','ibmssz@163.com');");

require("../../inc/footer.php");
?>